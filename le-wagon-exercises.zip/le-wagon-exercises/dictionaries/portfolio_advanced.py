# pylint: disable=missing-docstring

# TODO: start by defining a `portfolio` using a dict!

portfolio = {
    
  "AAPL": {"volume": 10, "strike": 154.12},
  
  "GOOG": {"volume": 2,  "strike": 812.56},
  
  "TSLA": {"volume": 12, "strike": 342.12},
  
  "META": {"volume": 18, "strike": 209.0}
  
}

print(portfolio['TSLA']['volume'])

print(portfolio['GOOG']['strike'])


market = {
    
  "AAPL": 198.84,
  
  "GOOG": 1217.93,
  
  "TSLA": 267.66,
  
  "META": 179.06
  
}


import requests

url = "https://iex.lewagon.com/stable/tops/last?symbols=AAPL,GOOG,TSLA,META"

real_time_market = requests.get(url).json()

print(real_time_market)

market = {}

for stock in real_time_market:
    
    market[stock['symbol']] = stock['price']

market = dict((stock['symbol'], stock['price']) for stock in real_time_market)

portfolio["AMZN"] = {
  
    "volume": 10,
    
    "strike": 1812.11
    
}


symbols = ",".join(portfolio.keys())

url = f"https://iex.lewagon.com/stable/tops/last?symbols={symbols}"

real_time_market = requests.get(url).json()









