# pylint: disable=missing-docstring
import math

# TODO: 1st exercise: Define the `forward_price` function
spot = 100
interest_rate = 0.1
time = 2/12

forward_price = spot * math.exp(time * interest_rate)

print(f"forward price is {forward_price}")

# TODO: 2nd exercise: Define the `short_pnl` function
def short_pnl(positions, mtm):
    pnl = 0
    for strike, price in zip(positions, mtm):
        pnl += strike - price
    return pnl


# Example data from the exercise
positions = [100, 140, 200]
mtm = [110, 120, 180]

# Compute and print the portfolio P&L
pnl_A = positions[0] - mtm[0]  # 100 - 110 = -10
pnl_B = positions[1] - mtm[1]  # 140 - 120 = 20
pnl_C = positions[2] - mtm[2]  # 200 - 180 = 20

print(f"P&L are respectively{pnl_A, pnl_B, pnl_C}, from the example")







