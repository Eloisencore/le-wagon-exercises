# pylint: disable=missing-docstring,invalid-name

def summify(x, y):
    pass

def multiply(x, y):
    pass
