# TODO: it's a playground, let's write some code (no unit tests to run here)

import math

radius = 10

perimeter = 2 * math.pi * radius
area = math.pi * radius ** 2

print(f"radius is set to {radius}")

print(f"Permiter of the circle is {round(perimeter, 1 )}")

print(f"Area of the disk {round(area, 1)}")


def circle_math(radius):
    perimeter = 2 * math.pi * radius
    area = math.pi * radius * radius
    return [perimeter,area]

# Copy-paste this code _after_ the `def circle_math...`

values = circle_math(10)
print(f"Radius=10 => Perimeter={round(values[0], 1)}, Area={round(values[1], 1)}")

values = circle_math(11)
print(f"Radius=11 => Perimeter={round(values[0], 1)}, Area={round(values[1], 1)}")