# pylint: disable=missing-docstring

aapl = [ 10, 154.12 ]
goog = [  2, 812.56 ]
tsla = [ 12, 342.12 ]
fb   = [ 18, 209.0  ]

portfolio = [ aapl, goog, tsla, fb ]

google = portfolio[3][0]

print(f"{google}")

# Market spot prices
market = [198.84, 1217.93, 267.66, 179.06]

# Compute total P&L
pnl = 0

for i in range(len(portfolio)):

    volume = portfolio[i][0]      # first element of inner list
    strike = portfolio[i][1]      # second element of inner list
    spot   = market[i]            # matching market price
    pnl += (spot - strike) * volume

print(f"Total P&L: {pnl}")